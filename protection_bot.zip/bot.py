import os
import re
import sqlite3
import time
from collections import defaultdict

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ChatPermissions
from telegram.constants import ChatMemberStatus
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    ChatMemberHandler, ContextTypes, filters
)

BOT_TOKEN = os.getenv("8866015645:AAH2aJfnerdncEA27ELwHRmFn8w4x4ezG1c")
if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN environment variable is missing")

DB_FILE = "protection.db"
MAX_WARNINGS = 3
SPAM_LIMIT = 5
SPAM_WINDOW = 10

BAD_WORDS = {"badword1", "badword2", "spamword"}
URL_PATTERN = re.compile(r"(https?://|www\.|t\.me/|telegram\.me/)", re.I)
spam_tracker = defaultdict(list)

db = sqlite3.connect(DB_FILE, check_same_thread=False)
cur = db.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS settings (
    chat_id INTEGER PRIMARY KEY,
    anti_spam INTEGER DEFAULT 1,
    anti_link INTEGER DEFAULT 1,
    bad_words INTEGER DEFAULT 1,
    verification INTEGER DEFAULT 1,
    auto_ban INTEGER DEFAULT 1
)""")
cur.execute("""CREATE TABLE IF NOT EXISTS warnings (
    chat_id INTEGER, user_id INTEGER, warns INTEGER DEFAULT 0,
    PRIMARY KEY(chat_id, user_id)
)""")
cur.execute("""CREATE TABLE IF NOT EXISTS stats (
    chat_id INTEGER PRIMARY KEY,
    messages INTEGER DEFAULT 0, deleted INTEGER DEFAULT 0,
    banned INTEGER DEFAULT 0, muted INTEGER DEFAULT 0
)""")
db.commit()

def ensure_chat(chat_id):
    cur.execute("INSERT OR IGNORE INTO settings(chat_id) VALUES(?)", (chat_id,))
    cur.execute("INSERT OR IGNORE INTO stats(chat_id) VALUES(?)", (chat_id,))
    db.commit()

def settings(chat_id):
    ensure_chat(chat_id)
    cur.execute("SELECT anti_spam,anti_link,bad_words,verification,auto_ban FROM settings WHERE chat_id=?", (chat_id,))
    r = cur.fetchone()
    return dict(anti_spam=bool(r[0]), anti_link=bool(r[1]), bad_words=bool(r[2]),
                verification=bool(r[3]), auto_ban=bool(r[4]))

async def is_admin(update, user_id):
    try:
        m = await update.effective_chat.get_member(user_id)
        return m.status in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER)
    except Exception:
        return False

async def delete_message(message):
    try:
        await message.delete()
        cur.execute("UPDATE stats SET deleted=deleted+1 WHERE chat_id=?", (message.chat_id,))
        db.commit()
        return True
    except Exception:
        return False

async def add_warning(chat_id, user_id):
    cur.execute("INSERT OR IGNORE INTO warnings(chat_id,user_id,warns) VALUES(?,?,0)", (chat_id,user_id))
    cur.execute("UPDATE warnings SET warns=warns+1 WHERE chat_id=? AND user_id=?", (chat_id,user_id))
    cur.execute("SELECT warns FROM warnings WHERE chat_id=? AND user_id=?", (chat_id,user_id))
    n = cur.fetchone()[0]
    db.commit()
    return n

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🛡️ Protection Bot is active.\nUse /help to see commands.")

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🛡️ Protection commands\n\n"
        "/settings\n/antispam on|off\n/antilink on|off\n/badwords on|off\n"
        "/verify on|off\n/autoban on|off\n\n"
        "/warn (reply)\n/unwarn (reply)\n/mute (reply)\n/unmute (reply)\n"
        "/ban (reply)\n/unban USER_ID\n/stats\n/id"
    )

async def set_cmd(update, context, column):
    if not await is_admin(update, update.effective_user.id):
        return await update.message.reply_text("❌ Admin only.")
    if not context.args or context.args[0].lower() not in ("on","off"):
        return await update.message.reply_text("Usage: /command on|off")
    ensure_chat(update.effective_chat.id)
    value = 1 if context.args[0].lower() == "on" else 0
    cur.execute(f"UPDATE settings SET {column}=? WHERE chat_id=?", (value, update.effective_chat.id))
    db.commit()
    await update.message.reply_text(f"✅ {column.replace('_',' ').title()}: {'ON' if value else 'OFF'}")

async def antispam(u,c): await set_cmd(u,c,"anti_spam")
async def antilink(u,c): await set_cmd(u,c,"anti_link")
async def badwords(u,c): await set_cmd(u,c,"bad_words")
async def verify(u,c): await set_cmd(u,c,"verification")
async def autoban(u,c): await set_cmd(u,c,"auto_ban")

async def settings_cmd(update, context):
    if not await is_admin(update, update.effective_user.id): return
    s = settings(update.effective_chat.id)
    await update.message.reply_text(
        "⚙️ Settings\n\n" +
        "\n".join(f"{k}: {'ON' if v else 'OFF'}" for k,v in s.items())
    )

async def warn(update, context):
    if not await is_admin(update, update.effective_user.id): return
    if not update.message.reply_to_message: return await update.message.reply_text("Reply to a user's message.")
    target = update.message.reply_to_message.from_user
    if await is_admin(update, target.id): return
    n = await add_warning(update.effective_chat.id, target.id)
    if n >= MAX_WARNINGS:
        try:
            await update.effective_chat.ban_member(target.id)
            cur.execute("UPDATE stats SET banned=banned+1 WHERE chat_id=?", (update.effective_chat.id,))
            db.commit()
            await update.message.reply_text(f"🔨 {target.mention_html()} banned after {MAX_WARNINGS} warnings.", parse_mode="HTML")
        except Exception:
            await update.message.reply_text("❌ Ban failed. Check bot admin permissions.")
    else:
        await update.message.reply_text(f"⚠️ {target.mention_html()} warning {n}/{MAX_WARNINGS}", parse_mode="HTML")

async def unwarn(update, context):
    if not await is_admin(update, update.effective_user.id): return
    if not update.message.reply_to_message: return
    target = update.message.reply_to_message.from_user
    cur.execute("DELETE FROM warnings WHERE chat_id=? AND user_id=?", (update.effective_chat.id,target.id))
    db.commit()
    await update.message.reply_text("✅ Warning reset.")

async def mute(update, context):
    if not await is_admin(update, update.effective_user.id): return
    if not update.message.reply_to_message: return await update.message.reply_text("Reply to a user's message.")
    target = update.message.reply_to_message.from_user
    if await is_admin(update,target.id): return
    try:
        await update.effective_chat.restrict_member(target.id, permissions=ChatPermissions(can_send_messages=False))
        cur.execute("UPDATE stats SET muted=muted+1 WHERE chat_id=?", (update.effective_chat.id,))
        db.commit()
        await update.message.reply_text("🔇 User muted.")
    except Exception:
        await update.message.reply_text("❌ Mute failed.")

async def unmute(update, context):
    if not await is_admin(update, update.effective_user.id): return
    if not update.message.reply_to_message: return
    target = update.message.reply_to_message.from_user
    try:
        await update.effective_chat.restrict_member(target.id, permissions=ChatPermissions(
            can_send_messages=True, can_send_audios=True, can_send_documents=True,
            can_send_photos=True, can_send_videos=True, can_send_video_notes=True,
            can_send_voice_notes=True, can_send_polls=True, can_send_other_messages=True,
            can_add_web_page_previews=True))
        await update.message.reply_text("🔊 User unmuted.")
    except Exception:
        await update.message.reply_text("❌ Unmute failed.")

async def ban(update, context):
    if not await is_admin(update, update.effective_user.id): return
    if not update.message.reply_to_message: return await update.message.reply_text("Reply to a user's message.")
    target = update.message.reply_to_message.from_user
    if await is_admin(update,target.id): return
    try:
        await update.effective_chat.ban_member(target.id)
        cur.execute("UPDATE stats SET banned=banned+1 WHERE chat_id=?", (update.effective_chat.id,))
        db.commit()
        await update.message.reply_text("🔨 User banned.")
    except Exception:
        await update.message.reply_text("❌ Ban failed.")

async def unban(update, context):
    if not await is_admin(update, update.effective_user.id): return
    if not context.args: return await update.message.reply_text("/unban USER_ID")
    try:
        await update.effective_chat.unban_member(int(context.args[0]))
        await update.message.reply_text("✅ User unbanned.")
    except Exception:
        await update.message.reply_text("❌ Unban failed.")

async def protect(update, context):
    m = update.effective_message
    if not m or not m.from_user or m.chat.type not in ("group","supergroup"): return
    ensure_chat(m.chat_id)
    if await is_admin(update,m.from_user.id): return
    s = settings(m.chat_id)
    text = m.text or m.caption or ""
    cur.execute("UPDATE stats SET messages=messages+1 WHERE chat_id=?", (m.chat_id,))
    db.commit()

    if s["bad_words"] and text and any(w.lower() in text.lower() for w in BAD_WORDS):
        await delete_message(m)
        n = await add_warning(m.chat_id,m.from_user.id)
        await context.bot.send_message(m.chat_id, f"🚫 {m.from_user.mention_html()} bad word detected ({n}/{MAX_WARNINGS}).", parse_mode="HTML")
        if n >= MAX_WARNINGS and s["auto_ban"]:
            try:
                await m.chat.ban_member(m.from_user.id)
                cur.execute("UPDATE stats SET banned=banned+1 WHERE chat_id=?", (m.chat_id,)); db.commit()
            except Exception: pass
        return

    if s["anti_link"] and text and URL_PATTERN.search(text):
        await delete_message(m)
        await context.bot.send_message(m.chat_id, f"🔗 {m.from_user.mention_html()} links are blocked.", parse_mode="HTML")
        return

    if s["anti_spam"]:
        now = time.time()
        key = (m.chat_id,m.from_user.id)
        spam_tracker[key] = [t for t in spam_tracker[key] if now-t <= SPAM_WINDOW]
        spam_tracker[key].append(now)
        if len(spam_tracker[key]) >= SPAM_LIMIT:
            try:
                await m.chat.restrict_member(m.from_user.id, permissions=ChatPermissions(can_send_messages=False))
                cur.execute("UPDATE stats SET muted=muted+1 WHERE chat_id=?", (m.chat_id,)); db.commit()
                await m.chat.send_message(f"🛡️ {m.from_user.mention_html()} spam detected. Muted for 60 seconds.", parse_mode="HTML")
                context.job_queue.run_once(unmute_job, 60, data={"chat_id":m.chat_id,"user_id":m.from_user.id})
                spam_tracker[key]=[]
            except Exception: pass

async def unmute_job(context):
    d=context.job.data
    try:
        await context.bot.restrict_chat_member(d["chat_id"],d["user_id"],permissions=ChatPermissions(
            can_send_messages=True, can_send_audios=True, can_send_documents=True,
            can_send_photos=True, can_send_videos=True, can_send_video_notes=True,
            can_send_voice_notes=True, can_send_polls=True, can_send_other_messages=True,
            can_add_web_page_previews=True))
    except Exception: pass

async def new_member(update, context):
    cm=update.chat_member
    if not cm or cm.new_chat_member.status != ChatMemberStatus.MEMBER: return
    if cm.old_chat_member.status not in (ChatMemberStatus.LEFT,ChatMemberStatus.BANNED): return
    user=cm.new_chat_member.user
    if user.is_bot or not settings(update.effective_chat.id)["verification"]: return
    try:
        await context.bot.restrict_chat_member(update.effective_chat.id,user.id,permissions=ChatPermissions(can_send_messages=False))
        kb=InlineKeyboardMarkup([[InlineKeyboardButton("✅ Verify",callback_data=f"verify:{user.id}")]])
        msg=await context.bot.send_message(update.effective_chat.id,f"👋 Welcome {user.mention_html()}!\nVerify to chat.",reply_markup=kb,parse_mode="HTML")
        context.job_queue.run_once(remove_verify,120,data={"chat_id":update.effective_chat.id,"user_id":user.id,"message_id":msg.message_id})
    except Exception: pass

async def verify_callback(update, context):
    q=update.callback_query; await q.answer()
    uid=int(q.data.split(":")[1])
    if q.from_user.id != uid: return await q.answer("❌ Not your button.",show_alert=True)
    try:
        await context.bot.restrict_chat_member(q.message.chat_id,uid,permissions=ChatPermissions(
            can_send_messages=True, can_send_audios=True, can_send_documents=True,
            can_send_photos=True, can_send_videos=True, can_send_video_notes=True,
            can_send_voice_notes=True, can_send_polls=True, can_send_other_messages=True,
            can_add_web_page_previews=True))
        await q.edit_message_text(f"✅ {q.from_user.mention_html()} verified!",parse_mode="HTML")
    except Exception: await q.answer("❌ Verification failed.",show_alert=True)

async def remove_verify(context):
    d=context.job.data
    try:
        m=await context.bot.get_chat_member(d["chat_id"],d["user_id"])
        if m.status==ChatMemberStatus.RESTRICTED:
            await context.bot.ban_chat_member(d["chat_id"],d["user_id"])
            cur.execute("UPDATE stats SET banned=banned+1 WHERE chat_id=?", (d["chat_id"],)); db.commit()
        await context.bot.delete_message(d["chat_id"],d["message_id"])
    except Exception: pass

async def stats(update, context):
    ensure_chat(update.effective_chat.id)
    cur.execute("SELECT messages,deleted,banned,muted FROM stats WHERE chat_id=?",(update.effective_chat.id,))
    r=cur.fetchone()
    await update.message.reply_text(f"📊 Stats\n\n💬 Messages: {r[0]}\n🗑️ Deleted: {r[1]}\n🔨 Banned: {r[2]}\n🔇 Muted: {r[3]}")

async def get_id(update, context):
    await update.message.reply_text(f"🆔 User ID: {update.effective_user.id}\n💬 Chat ID: {update.effective_chat.id}")

def main():
    app=Application.builder().token(BOT_TOKEN).build()
    handlers=[
        CommandHandler("start",start), CommandHandler("help",help_cmd),
        CommandHandler("settings",settings_cmd), CommandHandler("antispam",antispam),
        CommandHandler("antilink",antilink), CommandHandler("badwords",badwords),
        CommandHandler("verify",verify), CommandHandler("autoban",autoban),
        CommandHandler("warn",warn), CommandHandler("unwarn",unwarn),
        CommandHandler("mute",mute), CommandHandler("unmute",unmute),
        CommandHandler("ban",ban), CommandHandler("unban",unban),
        CommandHandler("stats",stats), CommandHandler("id",get_id),
        ChatMemberHandler(new_member,ChatMemberHandler.CHAT_MEMBER),
        CallbackQueryHandler(verify_callback,pattern=r"^verify:\d+$"),
        MessageHandler(filters.ALL & ~filters.COMMAND,protect)
    ]
    for h in handlers: app.add_handler(h)
    print("🛡️ Protection Bot started")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__=="__main__":
    main()
