# Telegram Protection Bot

## Setup
1. Create a bot with @BotFather and copy the token.
2. Set `BOT_TOKEN` as an environment variable.
3. Install:
   `pip install -r requirements.txt`
4. Run:
   `python bot.py`

## Telegram permissions
Add the bot to your group as Administrator and give it permission to:
- Delete messages
- Ban users
- Restrict users

## Commands
/settings
/antispam on|off
/antilink on|off
/badwords on|off
/verify on|off
/autoban on|off
/warn (reply)
/unwarn (reply)
/mute (reply)
/unmute (reply)
/ban (reply)
/unban USER_ID
/stats
/id

Edit BAD_WORDS in bot.py to add your own words.
Never upload your real bot token to a public Git repository.
